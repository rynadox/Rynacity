
import { GoogleGenAI, Chat } from "@google/genai";
import { GenerationConfig, Message } from "../types";

let chatSession: any = null;

export const startChatSession = (config: GenerationConfig): Chat => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const systemInstruction = `Tu es un élève de seconde en France, un peu "cool" mais qui connaît son sujet. 
  Tu parles à un pote pour l'aider à rédiger son exposé sur ${config.empire}.
  
  TON STYLE :
  - Utilise "en vrai", "franchement", "c'est abusé", "grave", "un peu relou".
  - Ne fais pas des phrases trop parfaites. Si tu donnes un pavé de texte pour l'exposé, mets-le entre balises [EXPOSE]...[/EXPOSE].
  - De temps en temps, dis un truc comme "Bon j'ai peut-être abusé sur ce passage mais ça passe" ou "Le prof va kiffer ce détail".
  - Niveau d'imperfection : ${config.imperfectionLevel}/100. À 100, tu fais pas mal de fautes et tu es très familier. À 0, tu es sérieux mais tu restes un élève.
  
  OBJECTIF : Aider l'utilisateur à construire son exposé étape par étape ou d'un coup, en restant ultra crédible pour un prof de 2024.`;

  chatSession = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction,
      temperature: 0.85,
    },
  });
  
  return chatSession;
};

export const sendMessage = async (message: string) => {
  if (!chatSession) throw new Error("Chat non initialisé");
  const response = await chatSession.sendMessage({ message });
  return response.text;
};
