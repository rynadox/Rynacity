
import React, { useState, useEffect, useRef } from 'react';
import { EmpireType, Message, GenerationConfig } from './types';
import { startChatSession, sendMessage } from './services/geminiService';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: "Salut ! Alors, on galère sur l'exposé d'histoire ? Dis-moi ce que tu veux faire sur l'empire colonial, je vais t'aider à pondre un truc qui passe crème." }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [config, setConfig] = useState<GenerationConfig>({
    empire: EmpireType.FRENCH,
    imperfectionLevel: 45
  });
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    startChatSession(config);
  }, [config.empire, config.imperfectionLevel]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const reply = await sendMessage(userMsg);
      setMessages(prev => [...prev, { role: 'model', text: reply }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'model', text: "Désolé, j'ai eu un bug de connexion... réessaie ?" }]);
    } finally {
      setLoading(false);
    }
  };

  const renderText = (text: string) => {
    // Détecte les blocs d'exposé pour les styliser différemment
    const parts = text.split(/\[EXPOSE\]|\[\/EXPOSE\]/);
    return parts.map((part, i) => {
      if (i % 2 === 1) {
        return (
          <div key={i} className="my-4 p-5 bg-yellow-50 border-l-4 border-yellow-400 font-serif text-slate-800 shadow-inner rounded-r-lg relative">
            <span className="absolute top-2 right-3 text-[10px] font-sans font-bold text-yellow-600 uppercase">Partie à recopier</span>
            {part}
          </div>
        );
      }
      return <span key={i}>{part}</span>;
    });
  };

  return (
    <div className="flex h-screen bg-slate-100 text-slate-900 overflow-hidden">
      {/* Sidebar - Paramètres */}
      <div className="w-80 bg-white border-r border-slate-200 p-6 hidden md:flex flex-col">
        <h1 className="text-2xl font-black text-indigo-600 mb-6 tracking-tighter uppercase">
          Exposé <span className="text-slate-400">GPT</span>
        </h1>
        
        <div className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Sujet de l'exposé</label>
            <select 
              className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500"
              value={config.empire}
              onChange={(e) => setConfig({...config, empire: e.target.value as EmpireType})}
            >
              {Object.values(EmpireType).map(e => <option key={e} value={e}>{e}</option>)}
            </select>
          </div>

          <div>
            <div className="flex justify-between mb-2">
              <label className="text-xs font-bold text-slate-500 uppercase">Niveau de "Flemme"</label>
              <span className="text-xs font-mono text-indigo-500 font-bold">{config.imperfectionLevel}%</span>
            </div>
            <input 
              type="range" 
              className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              value={config.imperfectionLevel}
              onChange={(e) => setConfig({...config, imperfectionLevel: parseInt(e.target.value)})}
            />
            <p className="text-[10px] text-slate-400 mt-2 leading-tight">
              Plus c'est haut, plus l'IA fera de petites erreurs volontaires pour paraître humaine.
            </p>
          </div>
        </div>

        <div className="mt-auto p-4 bg-indigo-50 rounded-2xl border border-indigo-100">
          <p className="text-xs text-indigo-700 leading-relaxed italic">
            "Conseil : Demande-lui de faire l'intro d'abord, puis les parties une par une pour que ça soit moins cramé."
          </p>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col relative">
        <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 p-4 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 font-bold">
              AI
            </div>
            <div>
              <h2 className="font-bold text-sm">IA de Seconde (Ton pote)</h2>
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">En ligne</span>
              </div>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] md:max-w-[70%] rounded-2xl p-4 text-sm md:text-base leading-relaxed ${
                m.role === 'user' 
                  ? 'bg-indigo-600 text-white rounded-br-none shadow-lg shadow-indigo-100' 
                  : 'bg-white text-slate-800 rounded-bl-none shadow-sm border border-slate-200'
              }`}>
                {renderText(m.text)}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="bg-white border border-slate-200 rounded-2xl rounded-bl-none p-4 shadow-sm">
                <div className="flex gap-1">
                  <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce"></span>
                  <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                  <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 bg-white border-t border-slate-200">
          <div className="max-w-4xl mx-auto flex gap-2">
            <input 
              type="text" 
              placeholder="Écris un message... (ex: 'Fais moi l'intro de l'exposé')"
              className="flex-1 p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-sm"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
            <button 
              onClick={handleSend}
              disabled={loading || !input.trim()}
              className="w-14 h-14 bg-indigo-600 text-white rounded-2xl flex items-center justify-center hover:bg-indigo-700 disabled:bg-slate-300 transition-all shadow-lg shadow-indigo-100"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 transform rotate-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
