
export enum EmpireType {
  FRENCH = 'Empire colonial français (19e-20e)',
  BRITISH = 'Empire britannique',
  SPANISH = 'Empire espagnol (Conquista)',
  PORTUGUESE = 'Empire portugais'
}

export interface Message {
  role: 'user' | 'model';
  text: string;
}

export interface GenerationConfig {
  empire: EmpireType;
  imperfectionLevel: number;
}
